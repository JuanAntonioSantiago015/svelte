import{l as o,b as r}from"../chunks/Cl2tfy-_.js";export{o as load_css,r as start};
